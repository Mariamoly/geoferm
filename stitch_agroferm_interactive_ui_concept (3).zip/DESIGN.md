---
name: Agroferm Monolith
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e2'
  on-secondary-container: '#646464'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  pure-white: '#FFFFFF'
  soft-border: '#E5E5E5'
  success-green: '#166534'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 64px
    fontWeight: '800'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The brand personality is authoritative, sophisticated, and utilitarian. It bridges the gap between raw industrial agriculture and high-end tech-driven efficiency. The target audience includes large-scale agricultural enterprises and investors who value clarity over decoration.

The design style is **High-Contrast Minimalism**. It utilizes a strict monochrome palette to create a "gallery-like" environment where the focus remains entirely on data and product imagery. Expect heavy use of whitespace (negative space), precision-engineered alignment, and a "Modernist" structural integrity. The emotional response should be one of absolute reliability, premium quality, and effortless navigation.

## Colors
The palette is intentionally restricted to high-contrast monochrome. 
- **Primary Black (#000000):** Used for all structural elements, primary text, and high-impact UI components.
- **Pure White (#FFFFFF):** The primary background color to maximize light and space.
- **Surface Gray (#F5F5F5):** Used for secondary layout containers, input fields, and subtle sectioning without breaking the monochrome flow.
- **Subtle Accents:** Grays are used strictly for secondary information and borders. A functional "Success Green" is reserved exclusively for final transaction confirmations or positive agricultural yield indicators, used sparingly.

## Typography
The typography utilizes **Hanken Grotesk** for its sharp, contemporary, and engineered feel. It provides the necessary weight for bold headings while maintaining excellent legibility at smaller scales.

**JetBrains Mono** is introduced for labels, metadata, and technical data points (e.g., coordinates, price per ton, SKU numbers) to reinforce the platform's precision-tech nature. Use tight letter-spacing for large displays and generous line-height for body copy to ensure a premium editorial feel.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop to maintain a curated, editorial appearance. Content is centered within a 1280px container.

- **Grid:** 12-column system for desktop, 4-column for mobile.
- **Rhythm:** An 8px linear scale.
- **Whitespace:** Use "excessive" margins between major sections (e.g., 128px or 160px) to distinguish the platform from crowded, low-end agricultural marketplaces.
- **Mobile:** Elements reflow into a single column with increased vertical padding to maintain the "premium" breathability on smaller screens.

## Elevation & Depth
In line with the Adjara Group inspiration, avoid shadows. Depth is communicated through **Tonal Layering** and **Low-contrast Outlines**.

- **Level 0:** Pure White (#FFFFFF) base.
- **Level 1:** Surface Gray (#F5F5F5) containers used for cards or secondary panels.
- **Interaction:** On hover, elements do not lift; they change fill color (e.g., from White to Black with inverted text) or gain a 1px solid black border. This "flat" approach emphasizes structural honesty over digital mimicry.

## Shapes
The shape language is strictly **Sharp (0px)**. No corner radii are permitted. This architectural approach reinforces the feeling of stability, permanence, and professional rigor. All buttons, cards, and input fields must feature hard 90-degree angles.

## Components
- **Custom Map Pins:** Inverted monochrome circles (Black background, White icon) with a needle-sharp point. Icons should be minimal glyphs representing product categories (e.g., a single grain stalk, a minimalist tractor).
- **Product Cards:** No borders. Use a light gray (#F5F5F5) background. The product image should be high-contrast. Product names are set in Bold Hanken Grotesk; prices are set in JetBrains Mono.
- **Buttons:** 
  - *Primary:* Solid Black background, White text, all-caps JetBrains Mono.
  - *Secondary:* 1px Black border, no fill.
- **Navigation:** A minimal horizontal bar. Logo on the left, 3-4 key links in the center, and a "Global Search" icon on the right. No background fill for the nav bar; it sits directly on the white background.
- **Input Fields:** Bottom-border only (1px Black) to mimic high-end stationary or architectural blueprints.